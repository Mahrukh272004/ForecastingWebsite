import React from "react";
import Topbar from "./topbar";
import "./dashboard.css";
import arima from "./images/arima.png";
import sarima from "./images/sarima.png";
import prophet from "./images/prophet.png";
import lstm from "./images/lstm.png";
import ann from "./images/ann.png";
import svr from "./images/svr.png";
import ets from "./images/ets.png";
import original from "./images/original.png";
import hybrid from "./images/hybrid.png";
import trend from "./images/trend.png"

const Dashboard = () => {
  // Mock data for the dashboard
  const statistics = [
    { image: arima, value: "" },
    { image: sarima, value: "" },
    { image: prophet, value: "" },
    { image: ets, value: "" },
    { image: ann, value: "" },
    { image: svr, value: "" },
    { image: lstm, value: "" },
    { image: hybrid, value: "" },
    { image: trend, value: "" },
  ];

  return (
    <div className="dashboard-container">
      <Topbar />
      <div className="dashboard-content">
        <h2 className="dashboard-title">Stock Price forecasting over years</h2>
        <div className="statistics-container">
          {/* Render big box */}
          <div className="big-statistic-card">
            <img src={original} alt="Original" />
            <h3 data-content="Original"></h3>
          </div>
          {/* Render other boxes */}
          {statistics.map((stat, index) => (
            <div key={index} className="statistic-card">
              <img src={stat.image} alt={stat.value} />
              <h3 data-content={stat.value}>{stat.value}</h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
