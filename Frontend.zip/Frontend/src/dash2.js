import React from "react";
import Topbar from "./topbar";
import "./dash2.css";
import arima from "./images2/arima.png";
import sarima from "./images2/sarima.png";
import prophet from "./images2/prophet.png";
import lstm from "./images2/lstm.png";
import ann from "./images2/ann.png";
import ets from "./images2/ets.png";
import original from "./images2/original.png";
import hybrid from "./images2/hybrid.png";

const Dashboard2 = () => {
  // Mock data for the dashboard
  const statistics = [
    { image: arima, value: "" },
    { image: sarima, value: "" },
    { image: prophet, value: "" },
    { image: ets, value: "" },
    { image: ann, value: "" },
    { image: lstm, value: "" },
    { image: hybrid, value: "" },
  ];

  return (
    <div className="dashboard-container">
      <Topbar />
      <div className="dashboard-content">
        <h2 className="dashboard-title">Co2 Concentration forecasting over years</h2>
        <div className="statistics-container">
          {/* Render big box */}
          <div className="big-statistic-card">
            <img src={original} alt="Original" />
            <h3 data-content="Original"></h3>
          </div>
          {/* Render other boxes */}
          {statistics.map((stat, index) => (
            <div key={index} className="statistic-card">
              <img src={stat.image} alt={stat.value} />
              <h3 data-content={stat.value}>{stat.value}</h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard2;
