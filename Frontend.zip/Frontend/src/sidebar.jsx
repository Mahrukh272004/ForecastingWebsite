import React, { useState } from "react";
import { Link } from "react-router-dom";
import DropdownMenu from "./DropdownMenu"; // Import the DropdownMenu component
import "./sidebar.css";

export default function Sidebar() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="sidebar">
      <div className="sidebarItem">
        <h1>
          Visuals
        </h1>
        <p className="paragraphtext">Welcome to our website, where we embark on an illuminating journey through the realms of data visualization. Here, we fuse the dynamic worlds of stock market trends and atmospheric science, offering a unique lens through which to observe and comprehend two crucial aspects of our modern world: stock prices and CO2 concentrations. Through cutting-edge models and interactive visuals, we aim to unravel the complexities of these datasets, providing insights into the intricate interplay between financial markets and environmental dynamics. Join us as we delve into the fluctuations of stocks and the shifting landscapes of CO2 levels, empowering you to navigate through the data-driven narratives shaping our global trajectory </p>
      </div>
      <div className="sidebarItem">
        <span className="sidebarTitle">MODELS</span>
        <ul className="sidebarList">
          <li className="sidebarListItem">
            <Link to="/arima" className="link">
              ARIMA
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/ann" className="link">
              ANN (Artificial Neural Networks)
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/ets" className="link">
              ETS (Exponential Smoothing State Space Model)
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/sarima" className="link">
              SARIMA (Seasonal Autoregressive Integrated Moving-Average)
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/svr" className="link">
              SVR (Support Vector Regression)
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/prophet" className="link">
              Prophet
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/lstm" className="link">
              LSTM (Long Short-Term Memory)
            </Link>
          </li>
          <li className="sidebarListItem">
            <Link to="/hybrid" className="link">
              Hybrid Model Integration
            </Link>
          </li>
        </ul>
      </div>
      <div className="sidebarItem">
        
        {isDropdownOpen && <DropdownMenu />}
      </div>
    </div>
  );
}
