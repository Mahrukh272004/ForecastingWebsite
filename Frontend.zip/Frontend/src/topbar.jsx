// Topbar.js
import React from "react";
import { Link } from "react-router-dom";
import "./topbar.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookSquare, faInstagramSquare, faPinterestSquare, faTwitterSquare } from '@fortawesome/free-brands-svg-icons';

const Topbar = () => {
  const user = true; // Assuming user is logged in
  return (
    <div className="top">   <div className="topLeft">
    <FontAwesomeIcon icon={faFacebookSquare} className="topIcon" />
    <FontAwesomeIcon icon={faInstagramSquare} className="topIcon" />
    <FontAwesomeIcon icon={faPinterestSquare} className="topIcon" />
    <FontAwesomeIcon icon={faTwitterSquare} className="topIcon" />
  </div>
      <div className="topCenter">
        <ul className="topList">
          <li className="topListItem">
            <Link className="link" to="/">
              Home
            </Link>
          </li>
          <li className="topListItem">
            <Link className="link" to="/compare"> {/* Link to Compare page */}
              Compare
            </Link></li>
            <li className="topListItem">
            <Link className="link" to="/Dashboard"> {/* Link to Compare page */}
              Dashboard
            </Link></li>
            <li className="topListItem">
            <Link className="link" to="/dash2"> {/* Link to Compare page */}
              Dashboard
            </Link></li>
      
      
    
          {/* Other list items */}
        </ul>
      </div>
      {/* Other parts of Topbar */}
    </div>
  );
};

export default Topbar;

