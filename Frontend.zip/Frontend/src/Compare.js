import React, { useState } from "react";
import "./Compare.css";
import arimaImage from "./images/arima.png";
import sarimaImage from "./images/sarima.png";
import svrImage from "./images/svr.png";
import prophetImage from "./images/prophet.png";
import annImage from "./images/ann.png";
import lstmImage from "./images/lstm.png";
import hybridImage from "./images/hybrid.png";
import etsImage from "./images/ets.png";
import ann2Image from "./images2/ann.png";
import arima2Image from "./images2/arima.png";
import hybrid2Image from "./images2/hybrid.png";
import ets2Image from "./images2/ets.png";
import sarima2Image from "./images2/sarima.png";
import prophet2Image from "./images2/prophet.png";

const Compare = () => {
  const [dataset, setDataset] = useState("");
  const [model1, setModel1] = useState("");
  const [model2, setModel2] = useState("");
  const [selectedDataset, setSelectedDataset] = useState("");

  const handleDatasetChange = (e) => {
    const selected = e.target.value;
    setDataset(selected);
    setSelectedDataset(selected);
    setModel1("");
    setModel2("");
  };

  const handleModel1Change = (e) => {
    setModel1(e.target.value);
  };

  const handleModel2Change = (e) => {
    setModel2(e.target.value);
  };

  const renderModelImage = (modelName) => {
    switch (selectedDataset) {
      case "CO2":
        return co2Models[modelName];
      case "S&P":
        return spModels[modelName];
      default:
        return null;
    }
  };

  // Define models and their respective images for CO2 dataset
  const co2Models = {
    ARIMA: arimaImage,
    SARIMA: sarimaImage,
    SVR: svrImage,
    Prophet: prophetImage,
    ANN: annImage,
    LSTM: lstmImage,
    Hybrid: hybridImage,
    ETS: etsImage,
    SARIMA: sarima2Image,
  };

  // Define models and their respective images for S&P dataset
  const spModels = {
    ARIMA: arima2Image,
    ANN: ann2Image,
    Hybrid: hybrid2Image,
    ETS: ets2Image,
    PROPHET: prophet2Image,

  };

  return (
    <div className="compare-container">
      <div className="compare-box">
        {/* Content for the first box */}
        <img src={renderModelImage(model1)} alt="Model 1" />
      </div>
      <select className="dropdown-menu" onChange={handleModel1Change}>
        <option value="">Select Model 1</option>
        {selectedDataset === "CO2" &&
          Object.keys(co2Models).map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
        {selectedDataset === "S&P" &&
          Object.keys(spModels).map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
      </select>
      <select className="dropdown-menu" onChange={handleModel2Change}>
        <option value="">Select Model 2</option>
        {selectedDataset === "CO2" &&
          Object.keys(co2Models).map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
        {selectedDataset === "S&P" &&
          Object.keys(spModels).map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
      </select>
      <div className="compare-box">
        {/* Content for the second box */}
        <img src={renderModelImage(model2)} alt="Model 2" />
      </div>
      <select className="dropdown-menu" onChange={handleDatasetChange}>
        <option value="">Select Dataset</option>
        <option value="CO2">S&P</option>
        <option value="S&P">Co2 Concentration</option>
      </select>
    </div>
  );
};

export default Compare;
