import React from "react";

export default function DropdownMenu() {
  return (
    <ul className="dropdownMenu">
      <li className="dropdownMenuItem">Option 1</li>
      <li className="dropdownMenuItem">Option 2</li>
      <li className="dropdownMenuItem">Option 3</li>
    </ul>
  );
}
