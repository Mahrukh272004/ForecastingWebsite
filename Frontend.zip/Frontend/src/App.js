// App.js
import React from "react";
import Topbar from "./topbar";
import Sidebar from "./sidebar";
import Compare from "./Compare";
import Dashboard from "./dasboard";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";
import Footer from "./footer"
import Dashboard2 from "./dash2";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dash2" element={<Dashboard2 />} />
        <Route path="/compare" element={<TopbarOnly />} />
        <Route path="/*" element={<WithSidebar />} />
      </Routes>
    </Router>
  );
}

function TopbarOnly() {
  return (
    <>
      <Topbar />
      <Compare />
    </>
  );
}

function WithSidebar() {
  return (
    <>
      <Topbar />
      <Sidebar />
      <Footer />
    </>
  );
}

export default App;
